export default class ResponseObject{
    returnCode:number;
    message:string;
    data:object;
}
